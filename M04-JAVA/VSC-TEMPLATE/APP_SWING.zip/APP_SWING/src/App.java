import com.rdk.config.ConfigDatabase;

public class App {
    public static void main(String[] args) throws Exception {
        ConfigDatabase.getConnection();
    }
}
